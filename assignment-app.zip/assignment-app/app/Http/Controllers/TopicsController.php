<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Topics;
use App\Models\Courses;

class TopicsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $minPrice = $request->input('minprice', 1000);
        $maxPrice = $request->input('maxprice', 10000);
        $order = $request->input('order','desc');
        $perPage = $request->input('per_page', 5); // Number of items per page (default: 5)
        $currentPage = $request->input('page', 1); // Current page (default: 1)
        $offset = ($currentPage - 1) * $perPage;
        $topics = $request->input('topics');

        $query = Courses::orderBy('id',$order)
            ->whereBetween('price', [$minPrice, $maxPrice]);

       
        if (isset($topics) && !empty($topics)) {
            $query->whereIn('topic_id', $topics);
        }
        $totalRecords = $query->count();

        $courses = $query->skip($offset)->take($perPage)->get();
        $topics  = Topics::get();
        return view('welcome')->with([
            'topics' => $topics,
            'courses' => $courses,
            'total_records' => $totalRecords,
            'per_page' => $perPage,
            'current_page' => $currentPage,
            'last_page' => ceil($totalRecords / $perPage),
            'selectedtopics' => $request['topics'],
            'maxPrice' => $maxPrice,
            'minPrice' => $minPrice,
            'order' => $request['order'],
        ]);
    }

    public function ajax(Request $request)
    {
        $minPrice = $request->input('minprice', 1000);
        $maxPrice = $request->input('maxprice', 10000);
        $perPage = $request->input('per_page', 5); // Number of items per page (default: 5)
        $currentPage = $request->input('page', 1); // Current page (default: 1)
        $offset = ($currentPage - 1) * $perPage;
        $topics = $request->input('topics');

        $query = Courses::orderBy('id', $request->input('order'))
            ->whereBetween('price', [$minPrice, $maxPrice]);

       
        if (isset($topics) && !empty($topics)) {
            $query->whereIn('topic_id', $topics);
        }
        $totalRecords = $query->count();

        $courses = $query->skip($offset)->take($perPage)->get();

        $returnHTML = view('ajaxresponse')->with([
            'courses' => $courses,
            'total_records' => $totalRecords,
            'per_page' => $perPage,
            'current_page' => $currentPage,
            'last_page' => ceil($totalRecords / $perPage)
        ])->render();

        return response()->json(['html' => $returnHTML]);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
