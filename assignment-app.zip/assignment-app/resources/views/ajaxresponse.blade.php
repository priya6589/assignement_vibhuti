@foreach($courses as $index => $value)
<div class="card mb-3">
    <div class="row g-0">
        <div class="col-md-4">
            <svg class="bd-placeholder-img img-fluid rounded-start" width="100%" height="250" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Image" preserveAspectRatio="xMidYMid slice" focusable="false">
                <title>Placeholder</title>
                <rect width="100%" height="100%" fill="#868e96"></rect><text x="50%" y="50%" fill="#dee2e6" dy=".3em">Image</text>
            </svg>
        </div>
        <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title">
                    <div class="row">
                        <div class="col-md-6">
                            {{$value->name}}
                        </div>
                        <div class="col-md-6">
                            <button type="button" class="btn btn-dark float-lg-end">Rs.{{$value->price}} Buy Now</button>
                        </div>
                    </div>
                </h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
            </div>
        </div>
    </div>
</div>
@endforeach
<div class="d-flex justify-content-center">
    <nav aria-label="Page navigation example">
        <ul class="pagination" id="pagination">
            <li class="page-item">
                <a class="page-link pagination-link" href="#" aria-label="Previous" data-page="{{($current_page == 1) ? 1 : $current_page-1}}">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            @for($i=1;$i<=$last_page;$i++) <li class="page-item">
                <a data-page='{{$i}}' href="#" class='pagination-link page-link {{$current_page == $i ? 'active' : ''}}'>{{$i}}</a>
                </li>
                @endfor
                <li class="page-item">
                    <a class="page-link pagination-link" href="#" aria-label="Next" data-page='{{($current_page != $last_page) ? $current_page+1 : 1}}'>
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
        </ul>
    </nav>
</div>