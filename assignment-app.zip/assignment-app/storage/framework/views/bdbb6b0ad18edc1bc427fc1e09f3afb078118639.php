<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Courses</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Styles -->
</head>

<body>
    <div class="container mt-3">
        <form class="form" id="filter-form" action="<?php echo e(route('ajax')); ?>">
            <div class="row">
                <div class="col-lg-4">
                    <div class="shadow-lg p-3 mb-5 bg-body-tertiary rounded">
                        <h2>Filters</h2>
                        <div class="accordion accordion-flush mt-2" id="accordionFlushExample">
                            <form class="form" id="filter-form">
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                            Topics
                                        </button>
                                    </h2>
                                    <div id="flush-collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                                        <div class="accordion-body">
                                            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check">
                                                <input class="form-check-input topics" type="checkbox" value="<?php echo e($value->id); ?>" id="topic<?php echo e($value->id); ?>" name="topics[]" <?php echo e((!empty($selectedtopics) && in_array($value['id'],$selectedtopics)) ? "checked" : ""); ?>>
                                                <label class="form-check-label" for="topic<?php echo e($value->id); ?>">
                                                    <?php echo e($value->name); ?>

                                                </label>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                            Price
                                        </button>
                                    </h2>
                                    <div id="flush-collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                                        <div class="accordion-body">
                                            <form id="price-range-form">
                                                <label for="min-price" class="form-label">Min price: </label>
                                                <span id="min-price-txt">Rs.<?php echo e($minPrice); ?></span>
                                                <input type="range" class="form-range" min="1000" max="9999" id="min-price" step="1" value="<?php echo e($minPrice); ?>" name="minprice">
                                                <label for="max-price" class="form-label">Max price: </label>
                                                <span id="max-price-txt">Rs.<?php echo e($maxPrice); ?></span>
                                                <input type="range" class="form-range" min="1000" max="10000" id="max-price" step="1" value="<?php echo e($maxPrice); ?>" name="maxprice">
                                            </form>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="row my-3">
                        <div class="col-lg-4">
                            <label for="">Search</label>
                            <div class="p-1 bg-light rounded rounded-pill shadow-sm mb-4">
                                <div class="input-group">
                                    <input type="search" placeholder="What're you searching for?" aria-describedby="button-addon1" class="form-control border-0 bg-light">
                                    <div class="input-group-append">
                                        <button id="button-addon1" type="submit" class="btn btn-link text-primary"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 offset-lg-4">
                            <label for="">Sorting</label>
                            <select class="form-select sorting" aria-label="Default select example" name='order' id="sorting">
                                <option value="desc" <?php echo e($order == 'desc' ? 'selected' : ''); ?>>Newest</option>
                                <option value="asc" <?php echo e($order == 'asc' ? 'selected' : ''); ?>>Ascending</option>
                            </select>
                        </div>
                    </div>
                    <div id='sortableList'>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-3">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <svg class="bd-placeholder-img img-fluid rounded-start" width="100%" height="250" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Image" preserveAspectRatio="xMidYMid slice" focusable="false">
                                        <title>Placeholder</title>
                                        <rect width="100%" height="100%" fill="#868e96"></rect><text x="50%" y="50%" fill="#dee2e6" dy=".3em">Image</text>
                                    </svg>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <?php echo e($value->name); ?>

                                                </div>
                                                <div class="col-md-6">
                                                    <button type="button" class="btn btn-dark float-lg-end">Rs.<?php echo e($value->price); ?> Buy Now</button>
                                                </div>
                                            </div>
                                        </h5>
                                        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                                        <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-center">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination" id="pagination">
                                    <li class="page-item">
                                        <a class="page-link pagination-link" href="#" aria-label="Previous" data-page="<?php echo e(($current_page == 1) ? 1 : $current_page-1); ?>">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                    <?php for($i=1;$i<=$last_page;$i++): ?> <li class="page-item">
                                        <a data-page='<?php echo e($i); ?>' href="#" class='pagination-link page-link <?php echo e($current_page == $i ? 'active' : ''); ?>'><?php echo e($i); ?></a>
                                        </li>
                                        <?php endfor; ?>
                                        <li class="page-item">
                                            <a class="page-link pagination-link" href="#" aria-label="Next" data-page='<?php echo e(($current_page != $last_page) ? $current_page+1 : 1); ?>'>
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <script>
        let min_price = 1000;
        let max_price = 10000;

        $(document).ready(function() {
            let currentPage = 1;
            let lastPage = 1;
            $("#min-price").on("change", function() {
                min_price = parseInt($("#min-price").val());
                $("#min-price-txt").text("Rs." + min_price);
                runfilter();
            });

            $("#max-price").on("change", function() {
                max_price = parseInt($("#max-price").val());
                $("#max-price-txt").text("Rs." + max_price);
                runfilter();
            });
            $('.topics').on('change', function(event) {
                event.preventDefault();
                // Serialize the form data
                runfilter();
            });



            // Function to load data using AJAX
            function loadData(page = 1) {
                var formData = $('#filter-form').serializeArray();
                formData.push({
                    name: 'page',
                    value: page
                }); // Append the 'page' parameter to the form data
                $.ajax({
                    type: 'POST',
                    url: $('#filter-form').attr("action"),
                    dataType: 'json',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: formData,
                    success: function(response) {
                        $('#sortableList').html(response.html);
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
                
                let urlSearchParams = new URLSearchParams(window.location.search);
                urlSearchParams.set('page', page);
                let newUrl = window.location.pathname + '?' + urlSearchParams.toString();
                history.pushState(null, null, newUrl);
            }

            // Listen for click events on pagination links
            $(document).on('click', '.pagination-link', function(e) {
                e.preventDefault();
                let page = $(this).data('page');
                loadData(page);
            });

            $(document).on('change', '#sorting', function(e) {
                e.preventDefault();
                runfilter();
            });

            function runfilter() {
                $.ajax({
                    type: 'POST',
                    url: $('#filter-form').attr("action"),
                    dataType: 'json',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: $('#filter-form').serializeArray(),
                    success: function(response) {
                        $('#sortableList').html(response.html);
                    },
                    error: function(error) {
                        alert('Error occurred');
                    },
                });
                let formData = $('#filter-form').serialize();
                let newUrl = '?' + formData;
                history.pushState(null, null, newUrl);
            }


        });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\Assignment\assignment-app\resources\views/welcome.blade.php ENDPATH**/ ?>