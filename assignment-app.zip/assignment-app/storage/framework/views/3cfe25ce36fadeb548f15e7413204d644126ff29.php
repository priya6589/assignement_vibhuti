<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card mb-3">
    <div class="row g-0">
        <div class="col-md-4">
            <svg class="bd-placeholder-img img-fluid rounded-start" width="100%" height="250" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Image" preserveAspectRatio="xMidYMid slice" focusable="false">
                <title>Placeholder</title>
                <rect width="100%" height="100%" fill="#868e96"></rect><text x="50%" y="50%" fill="#dee2e6" dy=".3em">Image</text>
            </svg>
        </div>
        <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title">
                    <div class="row">
                        <div class="col-md-6">
                            <?php echo e($value->name); ?>

                        </div>
                        <div class="col-md-6">
                            <button type="button" class="btn btn-dark float-lg-end">Rs.<?php echo e($value->price); ?> Buy Now</button>
                        </div>
                    </div>
                </h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="d-flex justify-content-center">
    <nav aria-label="Page navigation example">
        <ul class="pagination" id="pagination">
            <li class="page-item">
                <a class="page-link pagination-link" href="#" aria-label="Previous" data-page="<?php echo e(($current_page == 1) ? 1 : $current_page-1); ?>">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <?php for($i=1;$i<=$last_page;$i++): ?> <li class="page-item">
                <a data-page='<?php echo e($i); ?>' href="#" class='pagination-link page-link <?php echo e($current_page == $i ? 'active' : ''); ?>'><?php echo e($i); ?></a>
                </li>
                <?php endfor; ?>
                <li class="page-item">
                    <a class="page-link pagination-link" href="#" aria-label="Next" data-page='<?php echo e(($current_page != $last_page) ? $current_page+1 : 1); ?>'>
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
        </ul>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\Assignment\assignment-app\resources\views/ajaxresponse.blade.php ENDPATH**/ ?>