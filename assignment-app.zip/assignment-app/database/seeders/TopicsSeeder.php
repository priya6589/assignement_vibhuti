<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Topics;
class TopicsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $topics=[
            ['name'=>'Artificial Intelligence (AI) and Machine Learning'],
            ['name'=>'Robotics and Automation'],
            ['name'=>'Virtual Reality (VR) and Augmented Reality (AR)'],
            ['name'=>'Internet of Things (IoT)'],
            ['name'=>'Cryptocurrencies and Blockchain technology'],
            ['name'=>'Cybersecurity and Data Privacy'],
            ['name'=>'Climate Change and Environmental Sustainability'],
            ['name'=>'Renewable Energy Sources'],
            ['name'=>'Space Exploration and Astronomy'],
            ['name'=>'Biotechnology and Genetic Engineering'],
            ['name'=>'Nanotechnology and Nanomedicine'],
            ['name'=>'Quantum Computing'],
            ['name'=>'Sustainable Agriculture and Food Security'],
            ['name'=>'Mental Health and Well-being'],
            ['name'=>'Global Health and Disease Control'],
        ];

        foreach($topics as $key => $value)
        {
            Topics::create([
                "name" =>  $value['name'],
            ]);
        }
    }
}
