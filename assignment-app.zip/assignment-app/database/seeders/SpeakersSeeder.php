<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Speakers;
class SpeakersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $speakers=[
            ['name'=>'MR.John '],
            ['name'=>'MS.Anny Koshla'],
            ['name'=>'MR.Ayush Sharma'],
            ['name'=>'MR.Peter'],
            ['name'=>'MRS.Sheena'],
            ['name'=>'MRS.Anny Sharma'],
            ['name'=>'MR.Loreance'],
            ['name'=>'MR.Robin'],
            ['name'=>'MRS.Della'],
            ['name'=>'MR.Somnath Kumar'],
            ['name'=>'MS.Nany'],
            ['name'=>'MR.Loream'],
            ['name'=>'MS.Heena'],
            ['name'=>'MR.Sam'],
            ['name'=>'MR.Motten Kayal'],
        ];

        foreach($speakers as $key => $value)
        {
            Speakers::create([
                "name" =>  $value['name'],
            ]);
        }
    }
}
