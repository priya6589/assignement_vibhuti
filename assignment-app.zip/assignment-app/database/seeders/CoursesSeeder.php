<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Courses;
class CoursesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $courses =[
            ['name'=>'Introduction to AI','topic_id'=>'1','price_range'=>'3000-6000','price'=>'3200'],
            ['name'=>'Robotics Engineering','topic_id'=>'2','price_range'=>'2500-5000','price'=>'5000'],
            ['name'=>'Virtual Reality Development','topic_id'=>'3','price_range'=>'3500-4500','price'=>'4200'],
            ['name'=>'IoT Fundamentals','topic_id'=>'4','price_range'=>'5800-6500','price'=>'6000'],
            ['name'=>'Blockchain Basics','topic_id'=>'5','price_range'=>'8000-10000','price'=>'10000'],
            ['name'=>'Cybersecurity Fundamentals','topic_id'=>'6','price_range'=>'4500-7500','price'=>'7385'],
            ['name'=>'Environmental Science','topic_id'=>'7','price_range'=>'2500-3500','price'=>'3350'],
            ['name'=>'Renewable Energy Technologies','topic_id'=>'8','price_range'=>'2400-6500','price'=>'5500'],
            ['name'=>'Introduction to Astronomy','topic_id'=>'9','price_range'=>'3200-5000','price'=>'5000'],
            ['name'=>'Biotechnology Fundamentals','topic_id'=>'10','price_range'=>'5200-6800','price'=>'6000'],
            ['name'=>'Nanomaterials Science','topic_id'=>'11','price_range'=>'2200-3500','price'=>'3300'],
            ['name'=>'Quantum Algorithms','topic_id'=>'12','price_range'=>'4200-5500','price'=>'5350'],
            ['name'=>'Sustainable Agriculture Practices','topic_id'=>'13','price_range'=>'1200-2500','price'=>'1800'],
            ['name'=>'Mental Health Awareness','topic_id'=>'14','price_range'=>'2500-3500','price'=>'3000'],
            ['name'=>'Public Health Essentials','topic_id'=>'15','price_range'=>'2000-4200','price'=>'3500'],
        ];

        foreach($courses as $key => $value)
        {
            Courses::create([
                "name" =>  $value['name'],
                "topic_id" =>  $value['topic_id'],
                "price_range" =>  $value['price_range'],
                "price" =>  $value['price'],
            ]);
        }
    }
}
