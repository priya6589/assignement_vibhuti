<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\CourseSpeaker;
class CourseSpeakerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $course_speakers=[
            ['course_id'=>'1','speaker_id'=>'1'],
            ['course_id'=>'2','speaker_id'=>'3'],
            ['course_id'=>'3','speaker_id'=>'4'],
            ['course_id'=>'4','speaker_id'=>'5'],
            ['course_id'=>'5','speaker_id'=>'8'],
            ['course_id'=>'6','speaker_id'=>'7'],
            ['course_id'=>'7','speaker_id'=>'9'],
            ['course_id'=>'8','speaker_id'=>'6'],
            ['course_id'=>'9','speaker_id'=>'10'],
            ['course_id'=>'10','speaker_id'=>'2'],
            ['course_id'=>'11','speaker_id'=>'11'],
            ['course_id'=>'12','speaker_id'=>'12'],
            ['course_id'=>'13','speaker_id'=>'13'],
            ['course_id'=>'14','speaker_id'=>'14'],
            ['course_id'=>'15','speaker_id'=>'15'],


        ];

        foreach($course_speakers as $key => $value)
        {
            CourseSpeaker::create([
                "course_id" =>  $value['course_id'],
                "speaker_id" =>  $value['speaker_id'],
            ]);
        }
    }
}
